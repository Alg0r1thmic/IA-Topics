# Integrantes
-Kevin Salazar  Torres
-Brayan Maguiña del Castillo
-Raul Edgar Quispe Totocayo

# Nombre de Grupo
    Agosto


